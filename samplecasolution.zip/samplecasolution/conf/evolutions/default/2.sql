# --- Sample dataset

# --- !Ups

INSERT INTO department  VALUES (1, 'IT');
INSERT INTO department  VALUES (2, 'Sales');
INSERT INTO department  VALUES (3, 'HR');
INSERT INTO department  VALUES (4, 'Finance');


INSERT INTO PROJECT values(1,'Roads',50);
INSERT INTO PROJECT values(2,'Bridges',25);
INSERT INTO PROJECT values(3,'Buildings',25);


INSERT INTO ADDRESS VALUES(1,'1 Main Street','D24 WX23');
INSERT INTO ADDRESS VALUES(2,'10 New Street','D20 AB12');
INSERT INTO ADDRESS VALUES(3,'12 Old Street','D20 AB12');
INSERT INTO ADDRESS VALUES(4,'19 Big Street','D20 AB12');

INSERT INTO Employee VALUES (1,'JR','2018-02-27',1,1);
INSERT INTO Employee VALUES (2,'Bobby','2018-02-10',2,2);
INSERT INTO Employee VALUES (3,'Cliff','2018-02-18',3,3);
INSERT INTO Employee VALUES (4,'Jock','2017-02-16',4,4);

INSERT INTO employee_project VALUES(1, 1);
INSERT INTO employee_project VALUES(1, 2);
INSERT INTO employee_project VALUES(1, 3);




insert into user (email,name,password,role) values ( 'admin@company.com', 'Administrator', 'password', 'admin' );

insert into user (email,name,password,role) values ( 'manager@company.com', 'Manager', 'password', 'manager' );

insert into user (email,name,password,role) values ( 'customer@company.com', 'Customer', 'password', 'customer' );