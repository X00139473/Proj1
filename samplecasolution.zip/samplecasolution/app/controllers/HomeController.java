package controllers;

import play.mvc.*;
import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;
import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

import models.*;
import models.users.*;
import views.html.*;
import java.util.*;
import java.text.*;
import play.data.validation.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    private FormFactory formFactory;
    private Environment e;
    
        @Inject
        public HomeController(FormFactory f,Environment env) {
            this.formFactory = f;
            this.e = env;
        }
    
        public Result index(Long dep) {
            List<Employee> empList = null;
            List<Department> depList = Department.findAll();
            if (dep == 0) {
                empList = Employee.findAll();
            }
            else {
                empList = Department.find.ref(dep).getEmployees();
            }
            return ok(index.render(empList, depList, User.getUserById(session().get("email")),e));
        }

        @Security.Authenticated(Secured.class)
        public Result addEmployee() {
            Form<Employee> employeeForm = formFactory.form(Employee.class);
            return ok(addEmployee.render(employeeForm, User.getUserById(session().get("email"))));
        }
    
    
        @Security.Authenticated(Secured.class)
        public Result addEmployeeSubmit() 
        {
            Employee newEmployee;
            String saveImageMsg;
            Calendar cal=null;
            Date dDate = null;
            boolean convertDate=false;
            String n=null;
            String date=null;
            Address address = new Address();
    
            Form<Employee> newEmployeeForm = formFactory.form(Employee.class).bindFromRequest();
    
            if (newEmployeeForm.hasErrors()) {
                return badRequest(addEmployee.render(newEmployeeForm, User.getUserById(session().get("email")))); 
            }
            else {
                newEmployee = newEmployeeForm.value().get();
                newEmployee.save();

                //Associate the department with the employee
                String d =  newEmployeeForm.field("dep.id").getValue().get();
                newEmployee.setDepartment(Department.find.byId(Long.parseLong(d))); 
                newEmployee.update();
                //Set the address details 
                String addName = newEmployeeForm.field("address.addName").getValue().get();
                String eirCode = newEmployeeForm.field("address.eirCode").getValue().get();
                address.setAddressName(addName);
                address.seteirCode(eirCode);
                address.save();
    
                //Associate the address with the employee
                newEmployee.setAddress(address);                   
                newEmployee.update();   
                               
                Project project;
                List<Project> newProjects = new ArrayList<Project>();
                for(Long projs : newEmployee.getProjSelect()) {
                    project = Project.find.byId(projs);
                    newProjects.add(project);
                }

                newEmployee.pList = newProjects;
                newEmployee.update(); 
             }

                MultipartFormData data = request().body().asMultipartFormData();
                FilePart image = data.getFile("upload");
    
                saveImageMsg = saveFile(newEmployee.getId(), image);
    
                flash("success", "Employee " + newEmployee.getName() + " was added" + saveImageMsg);
    
                return redirect(controllers.routes.HomeController.index(0));
            }
    
    public String saveFile(Long id, FilePart<File> uploaded) {
        // make sure that the file exists
        if (uploaded != null) {
            // make sure that the content is indeed an image
            String mimeType = uploaded.getContentType(); 
            if (mimeType.startsWith("image/")) {
                // get the file name
                String fileName = uploaded.getFilename();                
                // save the file object (created without a path, File saves
                // the content to a default location, usually the temp or tmp
                // directory)
                File file = uploaded.getFile();
                // create an ImageMagik operation - this object is used to specify
                // the required image processing
                IMOperation op = new IMOperation();
                // add the uploaded image to the operationop.addImage(file.getAbsolutePath());
                op.addImage(file.getAbsolutePath());
                // resize the image using height and width saveFileOld(Long id, FilePart<File> uploaded) {
                op.resize(300, 200);
                // save the image as jpg 
                op.addImage("public/images/employeeImages/" + id + ".png");
                // create another Image Magick operation and repeat the process above to
                // specify how a thumbnail image should be processed - size 60px
                IMOperation thumb = new IMOperation();
                thumb.addImage(file.getAbsolutePath());
                thumb.resize(60);
                thumb.addImage("public/images/employeeImages/thumbnails/" + id + ".png");
                // we must make sure that the directories exist before running the operations
                File dir = new File("public/images/employeeImages/thumbnails/");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                // now we create an Image Magick command and execute the operations
                ConvertCmd cmd = new ConvertCmd();
                try {
                    cmd.run(op);
                    cmd.run(thumb);
                } catch(Exception e) {
                    e.printStackTrace();
                }
                return " and image saved";
            }
        }
        return "/ no file";
    }

    public Result employeeDetails(Long id) {
        Employee emp;

        emp = Employee.find.byId(id);
            
        return ok(employeeDetails.render(emp,User.getUserById(session().get("email")),e));
    }

}
