package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Project extends Model{

    @Id
    private Long id;
    private String name;
    private double duration;

    @ManyToMany(cascade = CascadeType.PERSIST)
    private List<Employee> eList = new ArrayList<>();

    public Project() {
    }

    public Project(String name, double duration) {
        this.name = name;
        this.duration = duration;
    }
    
    // Generic query helper for entity Project with id of type Long
    public static final Finder<Long, Project> find = new Finder<>(Project.class);

    // Return an array list of all Project objects
    public static final List<Project> findAll() {
        return Project.find.all();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public List<Employee> geteList() {
        return eList;
    }

    public void seteList(List<Employee> eList) {
        this.eList = eList;
    }

    public static Map<String, String> options() {
        LinkedHashMap<String, String> options = new LinkedHashMap<>();
        for (Project p : Project.findAll()) {
            options.put(p.getId().toString(), p.getName());
        }
        return options;
    }

}
