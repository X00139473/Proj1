package models;

import java.util.*;
import javax.persistence.*;
import java.text.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Employee extends Model {
    
        // Properties
        @Id
        private Long id;
        @Constraints.Required
        private String name;
        @Temporal(TemporalType.DATE)
        private Date startDate;
        @ManyToOne
        private Department dep;
        @OneToOne
        private Address address;
        @ManyToMany(cascade = CascadeType.PERSIST)
        public List<Project> pList;

        public static final Finder<Long, Employee> find = new Finder<>(Employee.class);
    

        public static final List<Employee> findAll() { 
            
            return Employee.find.all();
        }
        // Default Constructor
        public Employee() {
        }
    
        // Constructor to initialise object
        public Employee(Long id, String name, Date startDate, Department department, Address address) {
            this.id = id;
            this.name = name;
            this.startDate = startDate;
            this.dep = department;
            this.address = address;
        }
    
        // Accessor methods
        public Long getId() {
            return id;
        }
        public void setId(Long id) {
            this.id = id;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public Date getstartDate() {
            return startDate;
        }
        
        public void setstartDate(Date startDate) {
            this.startDate = startDate;
        }
        public Department getDepartment() { 
            return dep; 
        } 
        public void setDepartment(Department department) { 
            this.dep = department; 
        } 
        public Address getAddress() { 
            return address; 
        } 
        public void setAddress(Address address) { 
            this.address = address; 
        } 
        public List<Project> getpList() {
            return pList;
        }
    
        public void setpList(List<Project> pList) {
            this.pList = pList;
        }
        public List<String> getEmpsProjsNames(){
            List<String> projNames = new ArrayList<>();
              if(getpList().size() > 0){
                  for(int i = 0; i < getpList().size(); i++){
                    projNames.add(getpList().get(i).getName());
                  }
              } else {
                projNames.add("not currently placed on a proj");
              }
                 return projNames;
          }
          public List<Long> projSelect = new ArrayList<Long>();
        
        public List<Long> getProjSelect() {
            return projSelect;
        }
        public String getstartDateString() {
            if(startDate == null) {
                return "No Date Availible";
            }
            String s = new SimpleDateFormat("dd-MMM-yyyy").format(startDate.getTime());
            return s;
        }
    }
    